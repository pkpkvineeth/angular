import { Component, OnInit } from '@angular/core';
import { IProduct } from '../productlist/product.model'
@Component({
  selector: 'app-productadd',
  templateUrl: './productadd.component.html',
  styleUrls: ['./productadd.component.css']
})
export class ProductaddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
