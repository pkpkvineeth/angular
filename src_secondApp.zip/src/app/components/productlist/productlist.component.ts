import { Component, OnInit } from '@angular/core';
import { IProduct } from './product.model';
import { ProductsService } from '../../products.service';
@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  providers:[ProductsService],
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit 
{
pagetitle:string="Product List";
products:IProduct[];
showflag:Boolean=false;
check():void
{
  if(this.showflag)
      this.showflag=false;
  else
      this.showflag=true;    
}
  constructor(private p:ProductsService) { 
    this.products=this.p.getProducts();
  }

  ngOnInit() {
  }
 
}

