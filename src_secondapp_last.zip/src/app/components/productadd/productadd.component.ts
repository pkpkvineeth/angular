import { Component, OnInit } from '@angular/core';
import { IProduct } from '../productlist/product.model'
import { ProductsService } from '../../products.service';
@Component({
  selector: 'app-productadd',
  templateUrl: './productadd.component.html',
  styleUrls: ['./productadd.component.css']
})
export class ProductaddComponent implements OnInit {
  product=new IProduct(null,null,null,null,null,null,null,null);  
  constructor(private p:ProductsService) { 
  }
  ngOnInit() {
  }
  addproduct()
  {
    console.log(this.product)
    this.p.newProduct(this.product);
  }
}
