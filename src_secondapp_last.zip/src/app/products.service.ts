import { Injectable } from '@angular/core';
import { HttpClient,HttpResponse } from '@angular/common/http'
import { IProduct } from './components/productlist/product.model'
@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  constructor(private http:HttpClient) { }
  getProducts()
  {
  return new Promise((resolve, reject) => {
    this.http.get('http://localhost:3000/products').subscribe((data)=>
    {
      resolve(data);
    })
  })
   
  }
  newProduct(p:IProduct)
  {
    console.log("!!!!!!!!")
   this.http.post('http://localhost:3000/insert',{product:p}).subscribe((data)=>
   {
     alert(data);
   }
  )
  }
}
