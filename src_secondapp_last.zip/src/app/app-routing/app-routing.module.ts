import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes,RouterModule} from '@angular/router'
import { ProductlistComponent } from '../components/productlist/productlist.component'
import { ProductaddComponent } from '../components/productadd/productadd.component'
const routes:Routes=[
  {
    path:'',component:ProductlistComponent
  },
  {
    path:'add',component:ProductaddComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports:[RouterModule]
})
export class AppRoutingModule { }
