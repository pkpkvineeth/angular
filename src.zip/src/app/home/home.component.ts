import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: `./home.component.html`,
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  title:string = "My Home Page";
  name:string = "Vineeth P K";
  products:any[] = [
  {
    "Product_Id" : 1,
    "Product_Name": "Nike",
    "Product_Code": "3BT-XDF-5T7"  
  },
  {
    "Product_Id" : 2,
    "Product_Name": "Adidas",
    "Product_Code": "5GE-DFR-7RY" 
  },
  {
    "Product_Id" : 3,
    "Product_Name": "Reebok",
    "Product_Code": "67P-4YF-457" 
  }
]
  constructor() { }

  ngOnInit() {
  }

}
